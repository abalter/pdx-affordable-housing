"""
apply_manual_updates.py
=======================
Reads manual URL and notes additions from the No_Website sheet
of agent_review.xlsx and fetches/extracts data for those properties,
updating agent_results.json in place.

Workflow:
  1. Open agent_review.xlsx
  2. Go to No_Website sheet
  3. Add columns "Manual URL" and "Manual Notes" on the right
  4. Fill in URLs you found manually (and any notes you want)
  5. Run: python apply_manual_updates.py

The script will:
  - Read your manual URLs from the Excel
  - Fetch each page
  - Run Claude Haiku extraction on it
  - Update agent_results.json
  - Rebuild agent_review.xlsx

Usage:
    python apply_manual_updates.py              # process all manual URLs
    python apply_manual_updates.py --excel-only # just rebuild Excel, no fetching
"""

import argparse
import json
import os
import re
import time
from pathlib import Path

import requests
from bs4 import BeautifulSoup
from openpyxl import load_workbook

try:
    import anthropic
except ImportError:
    print("Missing: pip install anthropic"); raise

RESULTS_FILE = Path("agent_results.json")
EXCEL_FILE   = Path("agent_review.xlsx")
PROPS_JS     = Path("data/properties.js")
MODEL        = "claude-haiku-4-5-20251001"
FETCH_DELAY  = 0.8

HEADERS = {
    "User-Agent": (
        "pdx-affordable-housing/1.0 "
        "(nonprofit housing resource; github.com/abalter/pdx-affordable-housing)"
    )
}


def load_results():
    return json.loads(RESULTS_FILE.read_text(encoding="utf-8"))

def save_results(results):
    RESULTS_FILE.write_text(
        json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8"
    )

def load_properties():
    text     = PROPS_JS.read_text(encoding="utf-8")
    json_str = re.sub(r"^\s*const\s+PROPS\s*=\s*", "", text).rstrip().rstrip(";")
    return json.loads(json_str)


def fetch_page(url, max_chars=12000):
    try:
        r = requests.get(url, headers=HEADERS, timeout=15, allow_redirects=True)
        r.raise_for_status()
        soup = BeautifulSoup(r.text, "html.parser")
        for tag in soup(["script","style","nav","footer","header","aside"]):
            tag.decompose()
        text = soup.get_text(" ", strip=True)
        text = re.sub(r"\s{3,}", "\n", text)
        return text[:max_chars]
    except Exception as e:
        return f"FETCH_ERROR: {e}"


def extract_data(client, prop, page_text, url):
    system = """Extract affordable housing data from a property website.
Only extract info explicitly on the page. Use null for missing fields.
JSON only, no markdown:
{"rents":{"studio":null,"one_br":null,"two_br":null,"three_br":null},
 "waitlist":{"status":"open"|"closed"|"unknown","notes":null},
 "availability":null,"phone":null,"email":null,
 "amenities":[],"eligibility":null,"accepts_vouchers":null,
 "pet_policy":null,"parking":null,"notes":null}"""

    msg = f"""Property: {prop['name']}
Address: {prop['address']}, {prop['city']}
URL: {url}

Page content:
{page_text[:6000]}"""

    try:
        resp = client.messages.create(
            model=MODEL, max_tokens=1024,
            system=system,
            messages=[{"role":"user","content":msg}]
        )
        raw = re.sub(r"```json|```","", resp.content[0].text).strip()
        return json.loads(raw)
    except Exception as e:
        return {"parse_error": str(e)[:100]}


def read_manual_updates():
    """
    Read the No_Website sheet looking for 'Manual URL' and 'Manual Notes' columns.
    Returns list of (property_name, manual_url, manual_notes).
    """
    wb = load_workbook(EXCEL_FILE, read_only=True)

    if "No_Website" not in wb.sheetnames:
        print("No 'No_Website' sheet found in Excel.")
        return []

    ws = wb["No_Website"]
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []

    # Find column indices from header row
    headers = [str(h).strip() if h else "" for h in rows[0]]
    print(f"Columns found: {headers}")

    # Name is always column A (index 0)
    name_col = 0

    # Find Manual URL and Manual Notes columns
    url_col   = next((i for i, h in enumerate(headers) if "manual url"   in h.lower()), None)
    notes_col = next((i for i, h in enumerate(headers) if "manual notes" in h.lower()), None)

    if url_col is None:
        print("No 'Manual URL' column found.")
        print("Add a column named 'Manual URL' to the No_Website sheet.")
        return []

    updates = []
    for row in rows[1:]:
        if not row or not row[name_col]:
            continue
        name = str(row[name_col]).strip()
        url  = str(row[url_col]).strip() if row[url_col] else ""
        notes = str(row[notes_col]).strip() if notes_col and row[notes_col] else ""

        if url and url.lower() not in ("none","null","n/a",""):
            updates.append((name, url, notes))

    return updates


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--excel-only", action="store_true")
    args = parser.parse_args()

    if not all(f.exists() for f in [RESULTS_FILE, EXCEL_FILE, PROPS_JS]):
        print("Missing files — run from repo root with agent_results.json and agent_review.xlsx present")
        return

    results    = load_results()
    properties = load_properties()
    props_by_name = {p["name"].strip().lower(): p for p in properties}

    if args.excel_only:
        # Just rebuild Excel from current results
        from property_agent import build_excel
        build_excel(results, properties)
        return

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("Set ANTHROPIC_API_KEY environment variable")
    client = anthropic.Anthropic(api_key=api_key)

    manual_updates = read_manual_updates()
    if not manual_updates:
        print("No manual URLs found. Add a 'Manual URL' column to the No_Website sheet.")
        return

    print(f"\nFound {len(manual_updates)} manual URL(s) to process:\n")

    for name, url, manual_notes in manual_updates:
        print(f"  {name}")
        print(f"  URL: {url}")

        # Find matching result by name
        prop = props_by_name.get(name.lower())
        matching_id = None

        for pid, res in results.items():
            if res.get("name","").strip().lower() == name.lower():
                matching_id = pid
                break

        if matching_id is None:
            print(f"  ⚠ No matching property found for '{name}' — skipping\n")
            continue

        if not prop:
            # Fall back to result data
            r = results[matching_id]
            prop = {"name": r.get("name",""), "address": r.get("address",""),
                    "city": r.get("city",""), "program": r.get("program","")}

        # Fetch the page
        time.sleep(FETCH_DELAY)
        page_text = fetch_page(url)

        if "FETCH_ERROR" in page_text:
            print(f"  ✗ Fetch failed: {page_text}\n")
            results[matching_id]["error"] = page_text
            results[matching_id]["website_url"] = url
            results[matching_id]["url_confidence"] = "manual"
            results[matching_id]["url_method"] = "manual"
            save_results(results)
            continue

        # Extract data
        extracted = extract_data(client, prop, page_text, url)

        # Update the result
        results[matching_id]["website_url"]    = url
        results[matching_id]["url_confidence"] = "manual"
        results[matching_id]["url_reasoning"]  = "Manually provided"
        results[matching_id]["url_method"]     = "manual"
        results[matching_id]["extracted"]      = extracted
        results[matching_id]["error"]          = None

        if manual_notes:
            results[matching_id]["manual_notes"] = manual_notes

        wl    = (extracted.get("waitlist") or {}).get("status","?")
        rents = extracted.get("rents") or {}
        found = [f"{k}:{v}" for k,v in rents.items() if v]
        print(f"  ✓ waitlist:{wl}  rents:{found or 'none'}")
        if manual_notes:
            print(f"  📝 Notes: {manual_notes}")
        print()

        save_results(results)

    print(f"✓ Updated {len(manual_updates)} properties in {RESULTS_FILE}")

    # Rebuild Excel
    print("Rebuilding Excel...")
    from property_agent import build_excel
    build_excel(results, properties)
    print(f"✓ {EXCEL_FILE} updated")


if __name__ == "__main__":
    main()
